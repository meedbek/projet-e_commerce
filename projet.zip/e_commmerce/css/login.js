alert('helloc');
$('button').mouseover(function(){
    $('img').fadeOut().fadeIn(1000);
    alert('hello');
    
})

